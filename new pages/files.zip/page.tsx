import type { Metadata } from "next";
import { PrivacyPolicyContent } from "@/components/privacy-policy-content";

export const metadata: Metadata = {
  title: "Privacy Policy | Kroo Production",
  description:
    "Read the Privacy Policy of Kroo Production to understand how we collect, use and protect your information.",
  alternates: {
    canonical: "/privacy-policy",
  },
  openGraph: {
    title: "Privacy Policy | Kroo Production",
    description:
      "Read the Privacy Policy of Kroo Production to understand how we collect, use and protect your information.",
    url: "/privacy-policy",
    siteName: "Kroo Production",
    type: "website",
  },
};

export default function PrivacyPolicyPage() {
  return <PrivacyPolicyContent />;
}
