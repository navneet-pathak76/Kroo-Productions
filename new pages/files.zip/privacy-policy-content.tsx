"use client";

import { motion } from "framer-motion";
import type { ComponentType } from "react";
import Link from "next/link";
import {
  ChevronRight,
  Cookie,
  Database,
  ExternalLink,
  Eye,
  FileClock,
  Globe,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  RefreshCcw,
  ShieldCheck,
  ShieldQuestion,
  UserCog,
  Users,
  Youtube,
} from "lucide-react";
import { Ambient } from "@/components/ambient";
import { CursorFollower } from "@/components/cursor-follower";
import { SiteNav } from "@/components/site-nav";
import { services } from "@/lib/content";
import { useGsapReveal } from "@/hooks/use-gsap-reveal";
import { useLenis } from "@/hooks/use-lenis";
import { useMagnetic } from "@/hooks/use-magnetic";

const revealEase = [0.22, 1, 0.36, 1] as [number, number, number, number];

const fadeUp = {
  hidden: { y: 32, opacity: 0, filter: "blur(10px)" },
  visible: (i = 0) => ({
    y: 0,
    opacity: 1,
    filter: "blur(0px)",
    transition: {
      delay: i * 0.06,
      duration: 0.82,
      ease: revealEase,
    },
  }),
};

type PolicySection = {
  number: string;
  title: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  paragraphs?: string[];
  lists?: { heading?: string; items: string[] }[];
};

const sections: PolicySection[] = [
  {
    number: "01",
    title: "Information We Collect",
    icon: Database,
    lists: [
      {
        heading: "We may collect the following information:",
        items: [
          "Name",
          "Email address",
          "Phone number",
          "Company name",
          "Project details",
          "Budget information",
          "Any information voluntarily submitted through our contact forms or email communication.",
        ],
      },
      {
        heading: "We may also automatically collect:",
        items: [
          "IP address",
          "Browser type",
          "Device information",
          "Operating system",
          "Pages visited",
          "Referral source",
          "Date and time of visit",
        ],
      },
    ],
  },
  {
    number: "02",
    title: "How We Use Your Information",
    icon: Eye,
    lists: [
      {
        heading: "We use your information to:",
        items: [
          "Respond to project inquiries.",
          "Provide quotations.",
          "Deliver our services.",
          "Improve our website.",
          "Communicate regarding ongoing projects.",
          "Send updates related to our services (where permitted).",
          "Prevent fraud and protect our website.",
        ],
      },
    ],
  },
  {
    number: "03",
    title: "Cookies",
    icon: Cookie,
    paragraphs: [
      "Our website uses cookies and similar technologies to:",
    ],
    lists: [
      {
        items: [
          "Improve website performance.",
          "Remember user preferences.",
          "Measure website traffic.",
          "Analyze visitor behaviour.",
        ],
      },
    ],
  },
  {
    number: "04",
    title: "Third-Party Services",
    icon: Users,
    paragraphs: ["We may use trusted third-party services including:"],
    lists: [
      {
        items: [
          "Google Analytics",
          "Google Fonts",
          "AWS (Amazon Web Services)",
          "Cloudflare",
          "Social media platforms",
        ],
      },
    ],
  },
  {
    number: "05",
    title: "Data Retention",
    icon: FileClock,
    paragraphs: ["We retain your information only for as long as necessary to:"],
    lists: [
      {
        items: [
          "Provide our services.",
          "Comply with legal obligations.",
          "Resolve disputes.",
          "Maintain business records.",
        ],
      },
    ],
  },
  {
    number: "06",
    title: "Data Security",
    icon: ShieldCheck,
    paragraphs: [
      "Kroo Production implements reasonable administrative, technical, and organizational safeguards to protect your information.",
      "However, no method of transmission over the Internet or electronic storage is completely secure.",
    ],
  },
  {
    number: "07",
    title: "Your Rights",
    icon: UserCog,
    paragraphs: ["Depending on applicable laws, you may have the right to:"],
    lists: [
      {
        items: [
          "Request access to your information.",
          "Request correction of inaccurate information.",
          "Request deletion of your information.",
          "Withdraw consent where applicable.",
        ],
      },
    ],
  },
  {
    number: "08",
    title: "External Links",
    icon: ExternalLink,
    paragraphs: [
      "Our website may contain links to third-party websites.",
      "We are not responsible for the privacy practices or content of those external websites.",
    ],
  },
  {
    number: "09",
    title: "Children's Privacy",
    icon: ShieldQuestion,
    paragraphs: [
      "Our services are not intended for individuals under the age of 18.",
      "We do not knowingly collect personal information from children.",
    ],
  },
  {
    number: "10",
    title: "Changes to This Privacy Policy",
    icon: RefreshCcw,
    paragraphs: [
      "We reserve the right to update this Privacy Policy at any time.",
      "Any modifications will be published on this page with the updated Effective Date.",
    ],
  },
];

const contactDetails = [
  { label: "Website", value: "krooproduction.in", href: "https://krooproduction.in", icon: Globe },
  { label: "Email", value: "team@krooproduction.in", href: "mailto:team@krooproduction.in", icon: Mail },
  { label: "Phone", value: "+91 70030 87985", href: "tel:+917003087985", icon: Phone },
  { label: "Location", value: "Kolkata, West Bengal, India", href: undefined, icon: MapPin },
];

function PolicyHero() {
  return (
    <section className="relative scroll-mt-28 overflow-hidden px-5 pb-14 pt-32 sm:px-8 lg:px-5 lg:pb-20 lg:pt-40">
      <div className="pointer-events-none absolute right-[-16rem] top-10 h-[44rem] w-[44rem] rounded-full bg-primary/20 blur-[120px]" />
      <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:80px_80px] [mask-image:linear-gradient(to_bottom,transparent,black_18%,black_68%,transparent)]" />

      <div className="relative z-10 mx-auto max-w-[900px]">
        <motion.nav
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          aria-label="Breadcrumb"
          className="mb-8 flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-white/50"
        >
          <Link
            href="/"
            className="rounded-sm text-white/50 transition hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
          >
            Home
          </Link>
          <ChevronRight size={13} className="text-white/30" />
          <span className="text-primary">Privacy Policy</span>
        </motion.nav>

        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={1}
          className="mb-5 text-xs font-black uppercase tracking-[0.48em] text-primary sm:text-sm"
        >
          Legal
        </motion.p>
        <motion.h1
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={2}
          className="headline text-balance"
        >
          Privacy Policy
        </motion.h1>
        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={3}
          className="mt-5 text-xs font-black uppercase tracking-[0.24em] text-white/50"
        >
          Effective Date: 08 July 2026
        </motion.p>
        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={4}
          className="mt-8 max-w-2xl text-base leading-7 text-white/70 sm:text-lg lg:leading-8"
        >
          Welcome to Kroo Production. Your privacy is important to us. This
          Privacy Policy explains how we collect, use, disclose, and protect
          your information when you visit krooproduction.in or use our
          services.
        </motion.p>
      </div>
    </section>
  );
}

function PolicySections() {
  return (
    <section className="relative px-5 pb-8 sm:px-8">
      <div className="mx-auto max-w-[900px] space-y-5">
        {sections.map((section) => (
          <article
            key={section.number}
            data-reveal
            className="cinema-panel group rounded-md p-6 transition duration-500 hover:-translate-y-1 hover:border-primary/60 hover:shadow-glow sm:p-8"
          >
            <div className="mb-6 flex items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-xs font-black tracking-[0.06em] text-primary">
                  {section.number}
                </span>
                <h2 className="text-2xl font-black uppercase leading-tight text-white sm:text-3xl">
                  {section.title}
                </h2>
              </div>
              <section.icon
                className="hidden shrink-0 text-white/40 transition duration-300 group-hover:text-primary sm:block"
                size={26}
              />
            </div>

            {section.paragraphs?.map((paragraph, index) => (
              <p
                key={index}
                className="mt-3 text-base leading-7 text-white/62 first:mt-0"
              >
                {paragraph}
              </p>
            ))}

            {section.lists?.map((list, listIndex) => (
              <div key={listIndex} className="mt-5 first:mt-5">
                {list.heading && (
                  <p className="mb-3 text-sm font-black uppercase tracking-[0.08em] text-white/75">
                    {list.heading}
                  </p>
                )}
                <ul className="grid gap-2.5 sm:grid-cols-2">
                  {list.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2.5 text-sm leading-6 text-white/60"
                    >
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </article>
        ))}
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section className="relative px-5 py-8 sm:px-8 lg:py-12">
      <div className="mx-auto max-w-[900px]">
        <article
          data-reveal
          className="cinema-panel overflow-hidden rounded-md p-6 sm:p-8"
        >
          <div className="mb-6 flex items-center gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-xs font-black tracking-[0.06em] text-primary">
              11
            </span>
            <h2 className="text-2xl font-black uppercase leading-tight text-white sm:text-3xl">
              Contact Us
            </h2>
          </div>

          <p className="mb-7 text-lg font-black uppercase tracking-[0.06em] text-white">
            Kroo Production
          </p>

          <div className="grid gap-4 sm:grid-cols-2">
            {contactDetails.map((detail) => (
              <div
                key={detail.label}
                className="flex items-start gap-3.5 rounded-xl border border-white/10 bg-white/[0.025] p-4"
              >
                <detail.icon className="mt-0.5 shrink-0 text-primary" size={18} />
                <div className="min-w-0">
                  <p className="text-[0.68rem] font-black uppercase tracking-[0.2em] text-white/45">
                    {detail.label}
                  </p>
                  {detail.href ? (
                    <a
                      href={detail.href}
                      className="mt-1 block break-words text-sm font-bold text-white/80 transition hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
                    >
                      {detail.value}
                    </a>
                  ) : (
                    <p className="mt-1 text-sm font-bold text-white/80">
                      {detail.value}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <p className="mt-7 text-xs leading-6 text-white/45">
            To exercise any of the rights described above, please reach out
            using the contact details listed here.
          </p>
        </article>
      </div>
    </section>
  );
}

function SiteFooter() {
  return (
    <footer className="relative border-t border-white/10 px-5 py-10 sm:px-8">
      <div className="mx-auto grid max-w-[1480px] gap-8 md:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)_minmax(0,0.8fr)_minmax(0,0.8fr)]">
        <div>
          <div className="mb-5 flex items-center gap-3">
            <span className="text-4xl font-black text-primary">K</span>
            <span className="text-lg font-black uppercase tracking-[0.12em]">
              Kroo
            </span>
          </div>
          <p className="max-w-xs text-sm leading-6 text-white/50">
            Cinematic storytelling through powerful visuals and purposeful
            execution.
          </p>
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Quick links
          </h3>
          {["Home", "Work", "Team", "Services", "About", "Contact"].map(
            (item) => (
              <Link
                key={item}
                href={`/#${item.toLowerCase()}`}
                className="block rounded-sm py-1 text-sm text-white/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
              >
                {item}
              </Link>
            ),
          )}
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Services
          </h3>
          {services.map((service) => (
            <Link
              key={service.title}
              href="/#services"
              className="block rounded-sm py-1 text-sm text-white/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
            >
              {service.title}
            </Link>
          ))}
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Follow us
          </h3>
          <div className="flex gap-3">
            {[Instagram, Youtube, Linkedin].map((Icon, index) => (
              <a
                key={index}
                href="#"
                aria-label="Social link"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white/60 transition hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
              >
                <Icon size={17} />
              </a>
            ))}
          </div>
          <p className="mt-6 text-sm text-white/40">
            &copy; 2026 Kroo Production. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export function PrivacyPolicyContent() {
  useLenis();
  useGsapReveal();
  useMagnetic();

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#020202] text-white">
      <Ambient />
      <CursorFollower />
      <SiteNav />
      <div className="relative z-10">
        <PolicyHero />
        <PolicySections />
        <ContactSection />
        <SiteFooter />
      </div>
    </main>
  );
}
