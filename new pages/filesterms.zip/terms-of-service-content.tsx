"use client";

import { motion } from "framer-motion";
import type { ComponentType } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  Ban,
  Banknote,
  ChevronRight,
  Copyright,
  FileEdit,
  Gavel,
  Globe,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  RefreshCcw,
  ScrollText,
  ShieldAlert,
  Truck,
  UserCheck,
  Youtube,
} from "lucide-react";
import { Ambient } from "@/components/ambient";
import { CursorFollower } from "@/components/cursor-follower";
import { SiteNav } from "@/components/site-nav";
import { services } from "@/lib/content";
import { useGsapReveal } from "@/hooks/use-gsap-reveal";
import { useLenis } from "@/hooks/use-lenis";
import { useMagnetic } from "@/hooks/use-magnetic";

const revealEase = [0.22, 1, 0.36, 1] as [number, number, number, number];

const fadeUp = {
  hidden: { y: 32, opacity: 0, filter: "blur(10px)" },
  visible: (i = 0) => ({
    y: 0,
    opacity: 1,
    filter: "blur(0px)",
    transition: {
      delay: i * 0.06,
      duration: 0.82,
      ease: revealEase,
    },
  }),
};

type TermsSection = {
  number: string;
  title: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  paragraphs?: string[];
  lists?: { heading?: string; items: string[] }[];
};

const sections: TermsSection[] = [
  {
    number: "01",
    title: "About Us",
    icon: ScrollText,
    paragraphs: [
      "Kroo Production is a creative production house providing professional services including, but not limited to:",
    ],
    lists: [
      {
        items: [
          "Video production",
          "Commercial films",
          "Brand films",
          "Corporate videos",
          "Product photography",
          "Motion graphics",
          "Video editing",
          "Social media content creation",
          "Post-production services",
        ],
      },
    ],
  },
  {
    number: "02",
    title: "Website Usage",
    icon: ShieldAlert,
    paragraphs: [
      "You agree to use this website only for lawful purposes.",
      "You must not:",
    ],
    lists: [
      {
        items: [
          "Copy or reproduce website content without permission.",
          "Attempt to gain unauthorized access to our systems.",
          "Upload malicious software or harmful content.",
          "Misuse the website in any way that affects its performance or security.",
        ],
      },
    ],
  },
  {
    number: "03",
    title: "Intellectual Property",
    icon: Copyright,
    paragraphs: [
      "All content on this website, including videos, photographs, graphics, logos, designs, animations, text, and branding, is the property of Kroo Production unless otherwise stated.",
      "No material may be copied, reproduced, modified, or distributed without prior written permission.",
    ],
  },
  {
    number: "04",
    title: "Project Quotations & Payments",
    icon: Banknote,
    paragraphs: [
      "All quotations are valid for the period specified in the proposal.",
      "Project timelines begin only after:",
    ],
    lists: [
      {
        items: [
          "Quote approval",
          "Required advance payment (if applicable)",
          "Receipt of all necessary project materials",
        ],
      },
    ],
  },
  {
    number: "05",
    title: "Project Delivery",
    icon: Truck,
    paragraphs: ["Delivery timelines depend on:"],
    lists: [
      {
        items: [
          "Project complexity",
          "Client feedback",
          "Availability of required materials",
        ],
      },
    ],
  },
  {
    number: "06",
    title: "Client Responsibilities",
    icon: UserCheck,
    paragraphs: ["Clients are responsible for providing:"],
    lists: [
      {
        items: [
          "Accurate project information",
          "Required assets",
          "Timely feedback",
          "Necessary approvals",
        ],
      },
    ],
  },
  {
    number: "07",
    title: "Revisions",
    icon: FileEdit,
    paragraphs: [
      "Revision limits, if any, will be communicated during project confirmation.",
      "Additional revisions beyond the agreed scope may incur extra charges.",
    ],
  },
  {
    number: "08",
    title: "Cancellation",
    icon: Ban,
    paragraphs: [
      "Project cancellations after work has commenced may result in charges based on the work completed up to that point.",
      "Any advance payments already used toward project execution may be non-refundable.",
    ],
  },
  {
    number: "09",
    title: "Limitation of Liability",
    icon: AlertTriangle,
    paragraphs: [
      "Kroo Production shall not be liable for indirect, incidental, or consequential damages arising from the use of our website or services.",
    ],
  },
  {
    number: "10",
    title: "Third-Party Platforms",
    icon: Globe,
    paragraphs: [
      "Our website may contain links to third-party platforms including Instagram, LinkedIn, YouTube, and other services.",
      "We are not responsible for the content or privacy practices of those external websites.",
    ],
  },
  {
    number: "11",
    title: "Changes to These Terms",
    icon: RefreshCcw,
    paragraphs: [
      "We reserve the right to update these Terms & Conditions at any time without prior notice.",
      "The latest version will always be available on this page.",
    ],
  },
  {
    number: "12",
    title: "Governing Law",
    icon: Gavel,
    paragraphs: [
      "These Terms & Conditions shall be governed by the laws of India.",
      "Any disputes shall be subject to the jurisdiction of the competent courts of Kolkata, West Bengal.",
    ],
  },
];

const contactDetails = [
  { label: "Website", value: "krooproduction.in", href: "https://krooproduction.in", icon: Globe },
  { label: "Email", value: "team@krooproduction.in", href: "mailto:team@krooproduction.in", icon: Mail },
  { label: "Phone", value: "+91 70030 87985", href: "tel:+917003087985", icon: Phone },
  { label: "Location", value: "Kolkata, West Bengal, India", href: undefined, icon: MapPin },
];

function TermsHero() {
  return (
    <section className="relative scroll-mt-28 overflow-hidden px-5 pb-14 pt-32 sm:px-8 lg:px-5 lg:pb-20 lg:pt-40">
      <div className="pointer-events-none absolute right-[-16rem] top-10 h-[44rem] w-[44rem] rounded-full bg-primary/20 blur-[120px]" />
      <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:80px_80px] [mask-image:linear-gradient(to_bottom,transparent,black_18%,black_68%,transparent)]" />

      <div className="relative z-10 mx-auto max-w-[900px]">
        <motion.nav
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          aria-label="Breadcrumb"
          className="mb-8 flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-white/50"
        >
          <Link
            href="/"
            className="rounded-sm text-white/50 transition hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
          >
            Home
          </Link>
          <ChevronRight size={13} className="text-white/30" />
          <span className="text-primary">Terms of Service</span>
        </motion.nav>

        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={1}
          className="mb-5 text-xs font-black uppercase tracking-[0.48em] text-primary sm:text-sm"
        >
          Legal
        </motion.p>
        <motion.h1
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={2}
          className="headline text-balance"
        >
          Terms &amp; Conditions
        </motion.h1>
        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={3}
          className="mt-5 text-xs font-black uppercase tracking-[0.24em] text-white/50"
        >
          Effective Date: 08 July 2026
        </motion.p>
        <motion.p
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          custom={4}
          className="mt-8 max-w-2xl text-base leading-7 text-white/70 sm:text-lg lg:leading-8"
        >
          Welcome to Kroo Production. By accessing or using our website
          krooproduction.in or engaging with our services, you agree to the
          following Terms &amp; Conditions. If you do not agree with these
          terms, please refrain from using our website or services.
        </motion.p>
      </div>
    </section>
  );
}

function TermsSections() {
  return (
    <section className="relative px-5 pb-8 sm:px-8">
      <div className="mx-auto max-w-[900px] space-y-5">
        {sections.map((section) => (
          <article
            key={section.number}
            data-reveal
            className="cinema-panel group rounded-md p-6 transition duration-500 hover:-translate-y-1 hover:border-primary/60 hover:shadow-glow sm:p-8"
          >
            <div className="mb-6 flex items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-xs font-black tracking-[0.06em] text-primary">
                  {section.number}
                </span>
                <h2 className="text-2xl font-black uppercase leading-tight text-white sm:text-3xl">
                  {section.title}
                </h2>
              </div>
              <section.icon
                className="hidden shrink-0 text-white/40 transition duration-300 group-hover:text-primary sm:block"
                size={26}
              />
            </div>

            {section.paragraphs?.map((paragraph, index) => (
              <p
                key={index}
                className="mt-3 text-base leading-7 text-white/62 first:mt-0"
              >
                {paragraph}
              </p>
            ))}

            {section.lists?.map((list, listIndex) => (
              <div key={listIndex} className="mt-5 first:mt-5">
                {list.heading && (
                  <p className="mb-3 text-sm font-black uppercase tracking-[0.08em] text-white/75">
                    {list.heading}
                  </p>
                )}
                <ul className="grid gap-2.5 sm:grid-cols-2">
                  {list.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2.5 text-sm leading-6 text-white/60"
                    >
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </article>
        ))}
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section className="relative px-5 py-8 sm:px-8 lg:py-12">
      <div className="mx-auto max-w-[900px]">
        <article
          data-reveal
          className="cinema-panel overflow-hidden rounded-md p-6 sm:p-8"
        >
          <div className="mb-6 flex items-center gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-xs font-black tracking-[0.06em] text-primary">
              13
            </span>
            <h2 className="text-2xl font-black uppercase leading-tight text-white sm:text-3xl">
              Contact Information
            </h2>
          </div>

          <p className="mb-7 text-lg font-black uppercase tracking-[0.06em] text-white">
            Kroo Production
          </p>

          <div className="grid gap-4 sm:grid-cols-2">
            {contactDetails.map((detail) => (
              <div
                key={detail.label}
                className="flex items-start gap-3.5 rounded-xl border border-white/10 bg-white/[0.025] p-4"
              >
                <detail.icon className="mt-0.5 shrink-0 text-primary" size={18} />
                <div className="min-w-0">
                  <p className="text-[0.68rem] font-black uppercase tracking-[0.2em] text-white/45">
                    {detail.label}
                  </p>
                  {detail.href ? (
                    <a
                      href={detail.href}
                      className="mt-1 block break-words text-sm font-bold text-white/80 transition hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
                    >
                      {detail.value}
                    </a>
                  ) : (
                    <p className="mt-1 text-sm font-bold text-white/80">
                      {detail.value}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

function SiteFooter() {
  return (
    <footer className="relative border-t border-white/10 px-5 py-10 sm:px-8">
      <div className="mx-auto grid max-w-[1480px] gap-8 md:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)_minmax(0,0.8fr)_minmax(0,0.8fr)]">
        <div>
          <div className="mb-5 flex items-center gap-3">
            <span className="text-4xl font-black text-primary">K</span>
            <span className="text-lg font-black uppercase tracking-[0.12em]">
              Kroo
            </span>
          </div>
          <p className="max-w-xs text-sm leading-6 text-white/50">
            Cinematic storytelling through powerful visuals and purposeful
            execution.
          </p>
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Quick links
          </h3>
          {["Home", "Work", "Team", "Services", "About", "Contact"].map(
            (item) => (
              <Link
                key={item}
                href={`/#${item.toLowerCase()}`}
                className="block rounded-sm py-1 text-sm text-white/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
              >
                {item}
              </Link>
            ),
          )}
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Services
          </h3>
          {services.map((service) => (
            <Link
              key={service.title}
              href="/#services"
              className="block rounded-sm py-1 text-sm text-white/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
            >
              {service.title}
            </Link>
          ))}
        </div>
        <div>
          <h3 className="mb-4 text-sm font-black uppercase tracking-[0.18em] text-white">
            Follow us
          </h3>
          <div className="flex gap-3">
            {[Instagram, Youtube, Linkedin].map((Icon, index) => (
              <a
                key={index}
                href="#"
                aria-label="Social link"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white/60 transition hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4 focus-visible:ring-offset-black"
              >
                <Icon size={17} />
              </a>
            ))}
          </div>
          <p className="mt-6 text-sm text-white/40">
            &copy; 2026 Kroo Production. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export function TermsOfServiceContent() {
  useLenis();
  useGsapReveal();
  useMagnetic();

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#020202] text-white">
      <Ambient />
      <CursorFollower />
      <SiteNav />
      <div className="relative z-10">
        <TermsHero />
        <TermsSections />
        <ContactSection />
        <SiteFooter />
      </div>
    </main>
  );
}
